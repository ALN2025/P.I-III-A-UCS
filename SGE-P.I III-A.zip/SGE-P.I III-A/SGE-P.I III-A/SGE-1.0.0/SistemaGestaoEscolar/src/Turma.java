/**
 * ⩿ A.L.N/⪀
 * PROJETO INTEGRADOR III-A
 * Sistema de Gerenciamento Escolar
 */
import java.util.ArrayList;
import java.util.List;

public class Turma {
    public enum EtapaEnsino {
        INFANTIL("Infantil"),
        FUNDAMENTAL_ANOS_INICIAIS("Fundamental - Anos Iniciais"),
        FUNDAMENTAL_ANOS_FINAIS("Fundamental - Anos Finais"),
        MEDIO("Médio");

        private final String descricao;

        EtapaEnsino(String descricao) {
            this.descricao = descricao;
        }

        public String getDescricao() {
            return descricao;
        }
    }

    private String codigo;
    private EtapaEnsino etapaEnsino;
    private int ano;
    private int limiteVagas;
    private List<Aluno> alunosMatriculados;

    public Turma(String codigo, EtapaEnsino etapaEnsino, int ano, int limiteVagas) {
        this.codigo = codigo;
        this.etapaEnsino = etapaEnsino;
        this.ano = ano;
        this.limiteVagas = limiteVagas;
        this.alunosMatriculados = new ArrayList<>();
    }

    public boolean matricularAluno(Aluno aluno) {
        if (alunosMatriculados.size() < limiteVagas) {
            alunosMatriculados.add(aluno);
            return true;
        }
        return false;
    }

    public boolean verificarIdadeCompativel(Aluno aluno) {
        int idade = aluno.getIdade();
        return switch (etapaEnsino) {
            case INFANTIL -> idade < 6;
            case FUNDAMENTAL_ANOS_INICIAIS -> idade >= 6 && idade <= 11;
            case FUNDAMENTAL_ANOS_FINAIS -> idade >= 11 && idade <= 15;
            case MEDIO -> idade >= 15 && idade <= 18;
        };
    }

    public String getCodigo() { return codigo; }
    public EtapaEnsino getEtapaEnsino() { return etapaEnsino; }
    public int getAno() { return ano; }
    public int getLimiteVagas() { return limiteVagas; }
    public List<Aluno> getAlunosMatriculados() { return alunosMatriculados; }
    public int getNumeroMatriculados() { return alunosMatriculados.size(); }

    @Override
    public String toString() {
        return "Código: " + codigo + 
               ", Etapa: " + etapaEnsino.getDescricao() + 
               ", Ano: " + ano + 
               ", Vagas: " + (limiteVagas - alunosMatriculados.size()) + 
               "/" + limiteVagas;
    }
} 