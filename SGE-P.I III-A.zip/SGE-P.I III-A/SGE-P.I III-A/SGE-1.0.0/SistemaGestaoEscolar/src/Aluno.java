/**
 * ⩿ A.L.N/⪀
 * SISTEMA DE GERENCIAMENTO ESCOLAR
 * 
 * Estrutura do Sistema:
 * 
 * 1. Classes Principais:
 *    - Aluno: Armazena dados dos alunos (nome, CPF, endereço, data nascimento)
 *    - Turma: Gerencia turmas (código, etapa ensino, vagas, alunos)
 *    - ListaDeAlunos: Lista personalizada para gerenciar alunos
 *    - InterfaceGrafica: Interface visual do sistema
 * 
 * 2. Funcionalidades:
 *    - Cadastro de alunos e turmas
 *    - Matrícula de alunos
 *    - Consultas e listagens
 *    - Verificação de idade por etapa
 * 
 * 3. Regras Importantes:
 *    - Infantil: < 6 anos
 *    - Fundamental Anos Iniciais: 6-11 anos
 *    - Fundamental Anos Finais: 11-15 anos
 *    - Médio: 15-18 anos
 * 
 * 4. Interface:
 *    - Sistema de abas para organização
 *    - Formulários de cadastro
 *    - Área de consultas
 *    - Feedback visual
 * 
 * Desenvolvido para: UCS - Análise e Desenvolvimento de Sistemas
 * Projeto Integrador III-A
 */
import java.time.LocalDate;
import java.time.Period;

public class Aluno {
    private String nome;
    private String cpf;
    private String endereco;
    private LocalDate dataNascimento;

    public Aluno(String nome, String cpf, String endereco, LocalDate dataNascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.dataNascimento = dataNascimento;
    }

    public int getIdade() {
        return Period.between(dataNascimento, LocalDate.now()).getYears();
    }

    public String getNome() { return nome; }
    public String getCpf() { return cpf; }
    public String getEndereco() { return endereco; }
    public LocalDate getDataNascimento() { return dataNascimento; }

    @Override
    public String toString() {
        return "Nome: " + nome + 
               ", CPF: " + cpf + 
               ", Idade: " + getIdade() + 
               ", Endereço: " + endereco;
    }
} 