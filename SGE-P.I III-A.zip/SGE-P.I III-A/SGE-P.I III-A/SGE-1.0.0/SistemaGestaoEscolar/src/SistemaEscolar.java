import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SistemaEscolar {
    private ListaDeAlunos listaAlunos;
    private List<Turma> turmas;
    private Scanner scanner;
    private DateTimeFormatter dateFormatter;

    public SistemaEscolar() {
        listaAlunos = new ListaDeAlunos();
        turmas = new ArrayList<>();
        scanner = new Scanner(System.in);
        dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    }

    public void menu() {
        while (true) {
            System.out.println("\n=== SISTEMA ESCOLAR ===");
            System.out.println("1. Cadastrar Aluno");
            System.out.println("2. Cadastrar Turma");
            System.out.println("3. Matricular Aluno em Turma");
            System.out.println("4. Listar Alunos em Ordem Alfabética");
            System.out.println("5. Listar Turmas");
            System.out.println("6. Listar Alunos de uma Turma");
            System.out.println("7. Verificar Alunos Fora da Idade Prevista");
            System.out.println("0. Sair");
            
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer

            switch (opcao) {
                case 1 -> cadastrarAluno();
                case 2 -> cadastrarTurma();
                case 3 -> matricularAlunoEmTurma();
                case 4 -> listarAlunosOrdemAlfabetica();
                case 5 -> listarTurmas();
                case 6 -> listarAlunosTurma();
                case 7 -> verificarAlunosForaIdade();
                case 0 -> System.exit(0);
                default -> System.out.println("Opção inválida!");
            }
        }
    }

    private void cadastrarAluno() {
        System.out.println("\n=== CADASTRO DE ALUNO ===");
        
        System.out.print("Nome: ");
        String nome = scanner.nextLine();

        System.out.print("CPF: ");
        String cpf = scanner.nextLine();

        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();

        LocalDate dataNascimento = null;
        while (dataNascimento == null) {
            System.out.print("Data de Nascimento (dd/MM/yyyy): ");
            String dataStr = scanner.nextLine();
            try {
                dataNascimento = LocalDate.parse(dataStr, dateFormatter);
            } catch (DateTimeParseException e) {
                System.out.println("Data inválida! Use o formato dd/MM/yyyy");
            }
        }

        Aluno aluno = new Aluno(nome, cpf, endereco, dataNascimento);
        listaAlunos.incluirNoFim(aluno);
        System.out.println("Aluno cadastrado com sucesso!");
    }

    private void cadastrarTurma() {
        System.out.println("\n=== CADASTRO DE TURMA ===");
        
        System.out.print("Código da Turma: ");
        String codigo = scanner.nextLine();

        System.out.println("Etapa de Ensino:");
        System.out.println("1. Infantil");
        System.out.println("2. Fundamental - Anos Iniciais");
        System.out.println("3. Fundamental - Anos Finais");
        System.out.println("4. Médio");
        
        Turma.EtapaEnsino etapa = null;
        while (etapa == null) {
            int opcao = scanner.nextInt();
            etapa = switch (opcao) {
                case 1 -> Turma.EtapaEnsino.INFANTIL;
                case 2 -> Turma.EtapaEnsino.FUNDAMENTAL_ANOS_INICIAIS;
                case 3 -> Turma.EtapaEnsino.FUNDAMENTAL_ANOS_FINAIS;
                case 4 -> Turma.EtapaEnsino.MEDIO;
                default -> null;
            };
            if (etapa == null) System.out.println("Opção inválida!");
        }

        System.out.print("Ano: ");
        int ano = scanner.nextInt();

        System.out.print("Limite de Vagas: ");
        int limiteVagas = scanner.nextInt();

        Turma turma = new Turma(codigo, etapa, ano, limiteVagas);
        turmas.add(turma);
        System.out.println("Turma cadastrada com sucesso!");
    }

    private void matricularAlunoEmTurma() {
        System.out.println("\n=== MATRICULAR ALUNO EM TURMA ===");
        
        System.out.print("Nome do Aluno: ");
        String nomeAluno = scanner.nextLine();
        
        Aluno aluno = listaAlunos.buscarPorNome(nomeAluno);
        if (aluno == null) {
            System.out.println("Aluno não encontrado!");
            return;
        }

        System.out.print("Código da Turma: ");
        String codigoTurma = scanner.nextLine();
        
        Turma turma = turmas.stream()
                           .filter(t -> t.getCodigo().equals(codigoTurma))
                           .findFirst()
                           .orElse(null);

        if (turma == null) {
            System.out.println("Turma não encontrada!");
            return;
        }

        if (!turma.verificarIdadeCompativel(aluno)) {
            System.out.println("Idade do aluno não é compatível com a etapa de ensino!");
            return;
        }

        if (turma.matricularAluno(aluno)) {
            System.out.println("Aluno matriculado com sucesso!");
        } else {
            System.out.println("Não há vagas disponíveis nesta turma!");
        }
    }

    private void listarAlunosOrdemAlfabetica() {
        System.out.println("\n=== ALUNOS EM ORDEM ALFABÉTICA ===");
        listaAlunos.ordenar();
        
        for (int i = 0; i < listaAlunos.tamanho(); i++) {
            System.out.println(listaAlunos.get(i));
        }
    }

    private void listarTurmas() {
        System.out.println("\n=== TURMAS CADASTRADAS ===");
        if (turmas.isEmpty()) {
            System.out.println("Nenhuma turma cadastrada!");
            return;
        }
        
        for (Turma turma : turmas) {
            System.out.println(turma);
        }
    }

    private void listarAlunosTurma() {
        System.out.println("\n=== ALUNOS DA TURMA ===");
        System.out.print("Código da Turma: ");
        String codigo = scanner.nextLine();

        Turma turma = turmas.stream()
                           .filter(t -> t.getCodigo().equals(codigo))
                           .findFirst()
                           .orElse(null);

        if (turma == null) {
            System.out.println("Turma não encontrada!");
            return;
        }

        List<Aluno> alunosTurma = turma.getAlunosMatriculados();
        if (alunosTurma.isEmpty()) {
            System.out.println("Não há alunos matriculados nesta turma!");
            return;
        }

        for (Aluno aluno : alunosTurma) {
            System.out.println(aluno);
        }
    }

    private void verificarAlunosForaIdade() {
        System.out.println("\n=== ALUNOS FORA DA IDADE PREVISTA ===");
        System.out.println("Selecione a etapa de ensino:");
        System.out.println("1. Infantil");
        System.out.println("2. Fundamental - Anos Iniciais");
        System.out.println("3. Fundamental - Anos Finais");
        System.out.println("4. Médio");

        int opcao = scanner.nextInt();
        Turma.EtapaEnsino etapaSelecionada = switch (opcao) {
            case 1 -> Turma.EtapaEnsino.INFANTIL;
            case 2 -> Turma.EtapaEnsino.FUNDAMENTAL_ANOS_INICIAIS;
            case 3 -> Turma.EtapaEnsino.FUNDAMENTAL_ANOS_FINAIS;
            case 4 -> Turma.EtapaEnsino.MEDIO;
            default -> null;
        };

        if (etapaSelecionada == null) {
            System.out.println("Opção inválida!");
            return;
        }

        int alunosForaIdade = 0;
        for (Turma turma : turmas) {
            if (turma.getEtapaEnsino() == etapaSelecionada) {
                for (Aluno aluno : turma.getAlunosMatriculados()) {
                    if (!turma.verificarIdadeCompativel(aluno)) {
                        System.out.println(aluno);
                        alunosForaIdade++;
                    }
                }
            }
        }

        System.out.println("\nTotal de alunos fora da idade prevista: " + alunosForaIdade);
    }
} 