/**
 * ⩿ A.L.N/⪀
 * PROJETO INTEGRADOR III-A
 * Sistema de Gerenciamento Escolar
 */
public class ListaDeAlunos {
    private Aluno[] alunos;
    private int quantidade;
    private static final int CAPACIDADE_INICIAL = 100;

    public ListaDeAlunos() {
        alunos = new Aluno[CAPACIDADE_INICIAL];
        quantidade = 0;
    }

    public void incluirNoInicio(Aluno aluno) {
        if (quantidade == alunos.length) {
            redimensionarArray();
        }
        
        for (int i = quantidade; i > 0; i--) {
            alunos[i] = alunos[i-1];
        }
        alunos[0] = aluno;
        quantidade++;
    }

    public void incluirNoFim(Aluno aluno) {
        if (quantidade == alunos.length) {
            redimensionarArray();
        }
        alunos[quantidade++] = aluno;
    }

    public void ordenar() {
        for (int i = 0; i < quantidade - 1; i++) {
            for (int j = 0; j < quantidade - i - 1; j++) {
                if (alunos[j].getNome().compareTo(alunos[j + 1].getNome()) > 0) {
                    Aluno temp = alunos[j];
                    alunos[j] = alunos[j + 1];
                    alunos[j + 1] = temp;
                }
            }
        }
    }

    public Aluno removerDoFim() {
        if (quantidade == 0) return null;
        Aluno removido = alunos[quantidade - 1];
        alunos[quantidade - 1] = null;
        quantidade--;
        return removido;
    }

    public int tamanho() {
        return quantidade;
    }

    public Aluno get(int posicao) {
        if (posicao >= 0 && posicao < quantidade) {
            return alunos[posicao];
        }
        return null;
    }

    private void redimensionarArray() {
        Aluno[] novoArray = new Aluno[alunos.length * 2];
        System.arraycopy(alunos, 0, novoArray, 0, alunos.length);
        alunos = novoArray;
    }

    public Aluno buscarPorNome(String nome) {
        for (int i = 0; i < quantidade; i++) {
            if (alunos[i].getNome().equalsIgnoreCase(nome)) {
                return alunos[i];
            }
        }
        return null;
    }
} 