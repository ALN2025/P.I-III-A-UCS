import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.*;

/**
 * ⩿ A.L.N/⪀
 * PROJETO INTEGRADOR III-A
 * Sistema de Gerenciamento Escolar
 * Versão do APK: 1.0.0
 */
public class InterfaceGrafica extends JFrame {
    private ListaDeAlunos listaAlunos;
    private java.util.List<Turma> turmas;
    private DateTimeFormatter dateFormatter;
    private final String APP_VERSION = "1.0.0"; // Variável para armazenar a versão

    public InterfaceGrafica() {
        listaAlunos = new ListaDeAlunos();
        turmas = new java.util.ArrayList<>();
        dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Atualiza o título da janela com a versão
        setTitle("PROJETO INTEGRADOR III-A - Sistema de Gerenciamento Escolar - v" + APP_VERSION);

        // Criar painel principal com o cabeçalho
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Criar painel de cabeçalho
        JPanel headerPanel = new JPanel(new GridLayout(3, 1)); // Aumentado para 3 linhas para incluir versão
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        headerPanel.setBackground(new Color(0, 51, 102)); // Fundo azul escuro

        // Adicionar títulos
        JLabel titleLabel = new JLabel("PROJETO INTEGRADOR III-A", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);

        JLabel subtitleLabel = new JLabel("Sistema de Gerenciamento Escolar", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        subtitleLabel.setForeground(Color.WHITE);
        
        // Adicionar label de versão
        JLabel versionLabel = new JLabel("Versão do APK: " + APP_VERSION, SwingConstants.CENTER);
        versionLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        versionLabel.setForeground(Color.YELLOW);

        headerPanel.add(titleLabel);
        headerPanel.add(subtitleLabel);
        headerPanel.add(versionLabel);

        // Adicionar cabeçalho ao painel principal
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Criação do painel de abas
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Alunos", criarPainelAlunos());
        tabbedPane.addTab("Turmas", criarPainelTurmas());
        tabbedPane.addTab("Matrículas", criarPainelMatriculas());
        tabbedPane.addTab("Consultas", criarPainelConsultas());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Criar painel de informações
        JPanel infoPanel = criarPainelInformacoes();
        mainPanel.add(infoPanel, BorderLayout.SOUTH);
        
        // Adicionar rodapé com versão do sistema - NOVO
        JPanel footerPanel = new JPanel();
        footerPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        footerPanel.setBackground(new Color(51, 51, 51));
        
        JLabel footerVersionLabel = new JLabel("Sistema de Gerenciamento Escolar - Versão " + APP_VERSION, SwingConstants.CENTER);
        footerVersionLabel.setFont(new Font("Arial", Font.BOLD, 12));
        footerVersionLabel.setForeground(Color.WHITE);
        footerPanel.add(footerVersionLabel);
        
        // Criar painel contêiner para organizar o layout
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.add(mainPanel, BorderLayout.CENTER);
        containerPanel.add(footerPanel, BorderLayout.SOUTH);

        // Adicionar painel contêiner à janela
        add(containerPanel);

        // Aumentar tamanho da janela para acomodar o cabeçalho e rodapé
        setSize(800, 770);
        setLocationRelativeTo(null);
    }

    private JPanel criarPainelInformacoes() {
        JPanel panel = new JPanel(new GridLayout(6, 1)); // Aumentado para 6 linhas para incluir a versão e duplicação
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10),
            BorderFactory.createLineBorder(Color.GRAY)
        ));

        // Criar labels com fonte personalizada
        Font tituloFont = new Font("Arial", Font.BOLD, 16);
        Font textoFont = new Font("Arial", Font.PLAIN, 14);
        Font creditosFont = new Font("Arial", Font.BOLD, 12);
        Font versionFont = new Font("Arial", Font.ITALIC, 12);

        JLabel projetoLabel = new JLabel("PROJETO INTEGRADOR III-A", SwingConstants.CENTER);
        projetoLabel.setFont(tituloFont);

        JLabel cursoLabel = new JLabel("UCS - ANÁLISE E DESENVOLVIMENTO DE SISTEMAS", SwingConstants.CENTER);
        cursoLabel.setFont(textoFont);

        // Adicionar duplicidade de informação (erro proposital)
        JLabel projetoDuplicadoLabel = new JLabel("PROJETO INTEGRADOR III-A", SwingConstants.CENTER);
        projetoDuplicadoLabel.setFont(tituloFont);
        projetoDuplicadoLabel.setForeground(new Color(153, 0, 0)); // Cor vermelha escura para destacar o erro

        // Adicionar créditos
        JLabel creditosLabel = new JLabel("⩿ A.L.N/⪀", SwingConstants.CENTER);
        creditosLabel.setFont(creditosFont);
        creditosLabel.setForeground(new Color(0, 102, 204)); // Cor azul para destaque

        // Adicionar versão
        JLabel versionLabel = new JLabel("Versão do APK: " + APP_VERSION, SwingConstants.CENTER);
        versionLabel.setFont(versionFont);
        versionLabel.setForeground(new Color(0, 153, 0)); // Cor verde para destaque

        // Adicionar uma linha separadora
        JSeparator separator = new JSeparator();

        // Adicionar componentes ao painel
        panel.add(projetoLabel);
        panel.add(cursoLabel);
        panel.add(projetoDuplicadoLabel); // Duplicidade de informação (erro proposital)
        panel.add(separator);
        panel.add(creditosLabel);
        panel.add(versionLabel);

        // Definir cores de fundo e texto
        panel.setBackground(new Color(240, 240, 240));
        projetoLabel.setForeground(new Color(0, 51, 102));
        cursoLabel.setForeground(new Color(51, 51, 51));

        return panel;
    }

    private JPanel criarPainelAlunos() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Formulário de cadastro
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        JTextField nomeField = new JTextField();
        JTextField cpfField = new JTextField();
        JTextField enderecoField = new JTextField();
        JTextField dataNascField = new JTextField();

        formPanel.add(new JLabel("Nome:"));
        formPanel.add(nomeField);
        formPanel.add(new JLabel("CPF:"));
        formPanel.add(cpfField);
        formPanel.add(new JLabel("Endereço:"));
        formPanel.add(enderecoField);
        formPanel.add(new JLabel("Data Nascimento (dd/MM/yyyy):"));
        formPanel.add(dataNascField);

        JButton cadastrarButton = new JButton("Cadastrar Aluno");
        cadastrarButton.addActionListener(e -> {
            try {
                LocalDate dataNasc = LocalDate.parse(dataNascField.getText(), dateFormatter);
                Aluno aluno = new Aluno(
                    nomeField.getText(),
                    cpfField.getText(),
                    enderecoField.getText(),
                    dataNasc
                );
                listaAlunos.incluirNoFim(aluno);
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "Alun# c@d@str@do c0m suc3ss0! Versão " + APP_VERSION);
                
                // Limpar campos
                nomeField.setText("");
                cpfField.setText("");
                enderecoField.setText("");
                dataNascField.setText("");
            } catch (DateTimeParseException ex) {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "D@t@ inv@lid@! Us3 0 f0rm@t0 dd/MM/yyyy");
            }
        });

        formPanel.add(cadastrarButton);

        panel.add(formPanel, BorderLayout.NORTH);
        return panel;
    }

    private JPanel criarPainelTurmas() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Formulário de cadastro de turma
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5)); // Aumentado para 6 linhas para incluir versão
        JTextField codigoField = new JTextField();
        JComboBox<Turma.EtapaEnsino> etapaCombo = new JComboBox<>(Turma.EtapaEnsino.values());
        JTextField anoField = new JTextField();
        JTextField vagasField = new JTextField();

        formPanel.add(new JLabel("Código:"));
        formPanel.add(codigoField);
        formPanel.add(new JLabel("Etapa de Ensino:"));
        formPanel.add(etapaCombo);
        formPanel.add(new JLabel("Ano:"));
        formPanel.add(anoField);
        formPanel.add(new JLabel("Limite de Vagas:"));
        formPanel.add(vagasField);
        
        // Duplicidade de informação (erro proposital)
        formPanel.add(new JLabel("Limite de Vagas (duplo):"));
        formPanel.add(new JTextField());

        JButton cadastrarButton = new JButton("Cadastrar Turma");
        cadastrarButton.addActionListener(e -> {
            try {
                Turma turma = new Turma(
                    codigoField.getText(),
                    (Turma.EtapaEnsino) etapaCombo.getSelectedItem(),
                    Integer.parseInt(anoField.getText()),
                    Integer.parseInt(vagasField.getText())
                );
                turmas.add(turma);
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "T#rm@ c@d@str@d@ c0m suc3ss0! Versão " + APP_VERSION);
                
                // Limpar campos
                codigoField.setText("");
                anoField.setText("");
                vagasField.setText("");
            } catch (NumberFormatException ex) {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "V@l0r3s num3ric0s inv@lid0s!!!");
            }
        });

        formPanel.add(cadastrarButton);

        panel.add(formPanel, BorderLayout.NORTH);
        return panel;
    }

    private JPanel criarPainelMatriculas() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5)); // Aumentado para 4 linhas
        JTextField alunoField = new JTextField();
        JTextField turmaField = new JTextField();
        
        // Adicionar label de versão (duplicidade de informação)
        JLabel versionLabel = new JLabel("Versão do APK: " + APP_VERSION);
        versionLabel.setForeground(Color.BLUE);

        formPanel.add(new JLabel("Nome do Aluno:"));
        formPanel.add(alunoField);
        formPanel.add(new JLabel("Código da Turma:"));
        formPanel.add(turmaField);
        formPanel.add(versionLabel);
        formPanel.add(new JLabel("")); // Célula vazia

        JButton matricularButton = new JButton("Matricular");
        matricularButton.addActionListener(e -> {
            Aluno aluno = listaAlunos.buscarPorNome(alunoField.getText());
            if (aluno == null) {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "@lun0 n@0 3nc0ntr@d0!");
                return;
            }

            Turma turma = turmas.stream()
                               .filter(t -> t.getCodigo().equals(turmaField.getText()))
                               .findFirst()
                               .orElse(null);

            if (turma == null) {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "T#rm@ n@0 3nc0ntr@d@!");
                return;
            }

            if (!turma.verificarIdadeCompativel(aluno)) {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "Id@d3 d0 @lun0 n@0 é c0mp@tív3l c0m @ 3t@p@ d3 3nsin0!");
                return;
            }

            if (turma.matricularAluno(aluno)) {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "@lun0 m@tricul@d0 c0m suc3ss0! V3rs@0 " + APP_VERSION);
                alunoField.setText("");
                turmaField.setText("");
            } else {
                // Erro de caracteres no alerta (proposital)
                JOptionPane.showMessageDialog(this, "N@0 h@ v@g@s disp0nív3is n3st@ t#rm@!");
            }
        });

        formPanel.add(matricularButton);

        panel.add(formPanel, BorderLayout.NORTH);
        return panel;
    }

    private JPanel criarPainelConsultas() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel botoesPanel = new JPanel(new GridLayout(5, 1, 5, 5)); // Aumentado para 5 botões
        JTextArea resultadoArea = new JTextArea();
        resultadoArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadoArea);

        // Adicionar label de versão no topo (duplicidade de informação)
        JLabel versionLabel = new JLabel("Versão do APK: " + APP_VERSION + " - Versão do APK: " + APP_VERSION); // Duplicidade intencional
        versionLabel.setForeground(Color.RED);
        panel.add(versionLabel, BorderLayout.SOUTH);

        JButton listarAlunosButton = new JButton("Listar Alunos em Ordem Alfabética");
        listarAlunosButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("Versão do APK: ").append(APP_VERSION).append("\n\n"); // Adicionar versão (duplicidade)
            listaAlunos.ordenar();
            for (int i = 0; i < listaAlunos.tamanho(); i++) {
                sb.append(listaAlunos.get(i)).append("\n");
            }
            resultadoArea.setText(sb.toString());
        });

        JButton listarTurmasButton = new JButton("Listar Turmas");
        listarTurmasButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("List@g3m d3 T#rm@s - Versão: ").append(APP_VERSION).append("\n\n"); // Erro de caracteres proposital
            for (Turma turma : turmas) {
                sb.append(turma).append("\n");
            }
            resultadoArea.setText(sb.toString());
        });

        JButton listarAlunosTurmaButton = new JButton("Listar Alunos por Turma");
        listarAlunosTurmaButton.addActionListener(e -> {
            String codigo = JOptionPane.showInputDialog("Digit3 0 códig0 d@ t#rm@:"); // Erro de caracteres proposital
            if (codigo != null) {
                Turma turma = turmas.stream()
                                   .filter(t -> t.getCodigo().equals(codigo))
                                   .findFirst()
                                   .orElse(null);

                if (turma == null) {
                    resultadoArea.setText("T#rm@ n@0 3nc0ntr@d@! Versão: " + APP_VERSION); // Erro de caracteres proposital
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("@lun0s d@ T#rm@ ").append(codigo).append(" - Versão: ").append(APP_VERSION).append(":\n\n"); // Erro de caracteres proposital
                for (Aluno aluno : turma.getAlunosMatriculados()) {
                    sb.append(aluno).append("\n");
                }
                resultadoArea.setText(sb.toString());
            }
        });

        JButton verificarIdadesButton = new JButton("Verificar Alunos Fora da Idade");
        verificarIdadesButton.addActionListener(e -> {
            Object[] opcoes = Turma.EtapaEnsino.values();
            Turma.EtapaEnsino etapa = (Turma.EtapaEnsino) JOptionPane.showInputDialog(
                this,
                "S3l3ci0n3 @ 3t@p@ d3 3nsin0:", // Erro de caracteres proposital
                "Verificar Idades - Versão: " + APP_VERSION, // Adicionar versão
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]
            );

            if (etapa != null) {
                StringBuilder sb = new StringBuilder();
                int alunosForaIdade = 0;
                
                for (Turma turma : turmas) {
                    if (turma.getEtapaEnsino() == etapa) {
                        for (Aluno aluno : turma.getAlunosMatriculados()) {
                            if (!turma.verificarIdadeCompativel(aluno)) {
                                sb.append(aluno).append("\n");
                                alunosForaIdade++;
                            }
                        }
                    }
                }
                
                sb.append("\nT0t@l d3 @lun0s f0r@ d@ id@d3 pr3vist@: ").append(alunosForaIdade); // Erro de caracteres proposital
                sb.append("\nVersão do APK: ").append(APP_VERSION); // Adicionar versão
                resultadoArea.setText(sb.toString());
            }
        });
        
        // Botão adicional para mostrar versão (duplicidade proposital)
        JButton mostrarVersaoButton = new JButton("Mostrar Versão do APK");
        mostrarVersaoButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("Versã0 d0 @PK: ").append(APP_VERSION).append("\n"); // Erro de caracteres proposital
            sb.append("Versão do APK: ").append(APP_VERSION).append("\n"); // Duplicidade intencional
            sb.append("V3rsã0 d0 @PK: ").append(APP_VERSION).append("\n"); // Segunda duplicidade com erros
            resultadoArea.setText(sb.toString());
        });

        botoesPanel.add(listarAlunosButton);
        botoesPanel.add(listarTurmasButton);
        botoesPanel.add(listarAlunosTurmaButton);
        botoesPanel.add(verificarIdadesButton);
        botoesPanel.add(mostrarVersaoButton); // Adicionar novo botão

        panel.add(botoesPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }
} 