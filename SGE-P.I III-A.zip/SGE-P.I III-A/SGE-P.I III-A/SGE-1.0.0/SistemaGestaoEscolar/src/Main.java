/**
 * ⩿ A.L.N/⪀
 * PROJETO INTEGRADOR III-A
 * Sistema de Gerenciamento Escolar
 */

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InterfaceGrafica interfaceGrafica = new InterfaceGrafica();
            interfaceGrafica.setVisible(true);
        });
    }
} 